const axios = require('axios')
//const envslackurl = process.env.slackurl

exports.handler = function(event, context, callback) {
// console.log('Received event:', JSON.stringify(event, null, 4));

    var message = event.Records[0].Sns.Message;
    console.log('Message received from SNS:', message);
	
	axios
  .post('https://hooks.slack.com/services/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', {
    text: message
  })
  .then(res => {
    console.log(`statusCode: ${res.statusCode}`)
    console.log(res)
  })
  .catch(error => {
    console.error(error)
  });
  
    callback(null, "Success");
};